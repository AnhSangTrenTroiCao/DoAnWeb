﻿<?php
include 'Connection.php';

class NhanvienDeleteById extends Connection
{
	public $id;
	function execute()
	{
		return $this->query("DELETE FROM nhanvien WHERE NhanvienID = ".$this->id);
	}
}
class NhanvienInputDelete extends NhanvienDeleteById
{
	function execute()
	{
		parent::execute();
		return "<script>location.href='index.php?mod=100';</script>";
	}
	
}

?>