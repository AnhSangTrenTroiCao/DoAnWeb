﻿<?php 
	if(!isset($_GET['mod']))
		return;
	
	if($_GET['mod'] == '100')
	{	
		include 'NhanvienList.php';
		$item = new NhanvienList();
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '103')
	{	
		include 'NhanvienInput.php';
		$item = new NhanvienInput();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '102')
	{	
		include 'NhanvienInputDelete.php';
		$item = new NhanvienInputDelete();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '101')
	{	
		include 'NhanVienAdd.php';
		$item = new NhanvienForm();
		$item->execute();
		return;
	}
	if($_GET['mod'] == '104')
	{	
		include 'NhanvienEdit.php';
		$item = new NhanvienForm();
        $item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '107')
	{
		include 'DSNhVienXuatPdf.php';
        echo '<form action="DSNhVienXuatPdf.php" method="post">
                    <input type="submit" name="exportpdf" class="btn btn-success" value="Xuất" /> (Click vào để xuất dưới dạng PDF)
                </form>';
		return;
	}
	if($_GET['mod'] == '108')
	{
		include 'DSNhanVienXuatExcel.php';
        echo '<form action="DSNhanVienXuatExcel.php" method="post">
                    <input type="submit" name="exportexcel" class="btn btn-success" value="Xuất" /> (Click vào để xuất dưới dạng Excel)
                </form>';
		return;
	}
	if($_GET['mod'] == '200' )
	{	
		include 'KhachhangList.php';
		$item = new KhachhangList();
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '201')
	{	
		include 'KhachhangInput.php';
		$item = new KhachhangShow();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '202'){
		include 'KhachhangAdd.php';
		$item = new KhachHangForm();
		$item->execute();
		return;
	}
	if($_GET['mod'] == '203'){
		include 'KhachHangDelete.php';
		$item = new KhachHangDelete();
        $item->id = $_GET['ID'];
		$item->execute();
		return;
	}
	if($_GET['mod'] == '204'){
		include 'KhachHangEdit.php';
		$item = new KhachHangForm();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '300' )
	{	
		include 'NhacungcapList.php';
		$item = new NhacungcapList();
		echo $item->execute();
		return;
	}

	if($_GET['mod'] == '301')
	{	
		include 'NhacungcapInput.php';
		$item = new NhacungcapShow();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	
	if($_GET['mod'] == '302')
	{
		include 'NhacungcapAdd.php';
		$item = new NhacungcapForm();
		$item->execute();
		return;
	}
	if($_GET['mod'] == '303')
	{	
		include 'NhacungcapDelete.php';
		$item = new NhaCungCapDelete();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '304'){
		include 'NhacungcapEdit.php';
		$item = new NhaCungCapForm();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '400' )
	{	
		include 'NhomhanghoaList.php';
		$item = new NhomhanghoaList();
		echo $item->execute();
		return;
	}

	if($_GET['mod'] == '401')
	{	
		include 'NhomhanghoaInput.php';
		$item = new NhomhanghoaShow();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}

	if($_GET['mod'] == '402')
	{
		include 'NhomHangHoaAdd.php';
		$item = new NhomhanghoaForm();
		$item->execute();
		return;
	}
	if($_GET['mod'] == '403')
	{	
		include 'NhomHangHoaDelete.php';
		$item = new NhomHangHoaDelete();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '404'){
		include 'NhomHangHoaEdit.php';
		$item = new NhomHangHoaForm();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '500' )
	{	
		include 'HanghoaList.php';
		$item = new HanghoaList();
		echo $item->execute();
		return;
	}

	if($_GET['mod'] == '501')
	{	
		include 'HanghoaInput.php';
		$item = new HanghoaShow();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}

	if($_GET['mod'] == '502')
	{
		include 'HangHoaAdd.php';
		$item = new HanghoaForm();
		$item->execute();
		return;
	}
	if($_GET['mod'] == '503')
	{	
		include 'HangHoaDelete.php';
		$item = new HangHoaDelete();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '504'){
		include 'HangHoaEdit.php';
		$item = new HangHoaForm();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if ($_GET['mod']== '600'){
		include 'BanhangList.php';
		$item = new HanghoaList();
		echo $item -> execute();
	}
	if ($_GET['mod']== '601') {
        include 'Chitiethoadon.php';
        $item = new Chitiet();
        $item->HoadonID = $_GET['IDHoadon'];
        echo $item->execute();
    }
?> 
