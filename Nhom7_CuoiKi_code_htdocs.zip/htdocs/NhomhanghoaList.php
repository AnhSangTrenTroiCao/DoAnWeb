<?php
include 'Connection.php';

class NhomhanghoaSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM nhomhanghoa ORDER BY NhomhanghoaID DESC");
	}
}
class NhomhanghoaList extends NhomhanghoaSelectAll
{
	function execute()
	{
		$nhh = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($nhh as $arr)
		{	
			$html .= "<tr>";
				$html .= "<td></td>";	
				$html .= "<td>{$arr['NhomhanghoaID']}</td>";
				$html .= "<td>{$arr['Tennhomhanghoa']}</td>";
				$html .= "<td>{$arr['Ghichu']}</td>";

				$html.=	" <td><a class='btn2' title='Xoá' href = \"index.php?mod=403&ID={$arr['NhomhanghoaID']}\"><i class='fa fa-trash-o'></i></a>";
				$html .= "<a>  </a><a class='btn2' title='Sửa' href = \"index.php?mod=404&ID={$arr['NhomhanghoaID']}\"><i class='fa fa-edit'></a></td>";
			$html .= "</tr>";
		}
		$html .= $this->createFooter();
		return $html;
	}
	function createFooter()
	{
		$html = "";
			$html .= "</tbody>";
		$html .= "</table>";
		return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            $html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã Nhóm hàng hóa</th>";
                    $html .= "<th>Tên Nhóm hàng hóa</th>";
                    $html .= "<th>Ghi chú</th>";
                    $html .= "<th>Thao tác</th>";
                $html .= "</tr>";
			$html .= "</thead>";
        $html .= "<tbody>";
		return $html;
	}
}

?>
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style_button.css">
