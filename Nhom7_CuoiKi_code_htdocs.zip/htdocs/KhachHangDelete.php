<?php
include 'Connection.php';

class KhachHangDeleteById extends Connection
{
	var $id;
	function execute()
	{
		return $this->query("DELETE FROM khachhang WHERE KhachhangID = ".$this->id);
	}
}
class KhachHangDelete extends KhachHangDeleteById
{
	function execute()
	{
		parent::execute();
		return "<script>location.href='index.php?mod=200';</script>";
	}
	
}

?>