﻿<?php
include 'Connection.php';

class KhachhangSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM khachhang ORDER BY KhachhangID DESC");
	}
}
class KhachhangList extends KhachhangSelectAll
{
	function execute()
	{
		$nv = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($nv as $arr)
		{	
			$html .= "<tr>
				<td></td>
				<td>{$arr['KhachhangID']}</td>
				<td>{$arr['Holot']}</td>
				<td>{$arr['Ten']}</td>
				<td>{$arr['Sodienthoai']}</td>
				<td>{$arr['Sodiem']}</td>
				
				<td><a class='btn2' title='Xoá' href = \"index.php?mod=203&ID={$arr['KhachhangID']}\"><i class='fa fa-trash-o'></i></a>
				<a>  </a><a class='btn2' title='Sửa' href = \"index.php?mod=204&ID={$arr['KhachhangID']}\"><i class='fa fa-edit'></i></a></td>
		</tr>";
		}
		$html .= $this->createFooter();
		return $html;
	}
	function createFooter()
	{
		$html = "";
			$html .= "</tbody>";
		$html .= "</table>";
		return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            $html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã Khách hàng</th>";
                    $html .= "<th>Họ lót</th>";
                    $html .= "<th>Tên</th>";
					$html .= "<th>Điện thoại</th>";
					$html .= "<th>Số điểm</th>";
        			$html .= "<th>Thao tác</th>";
				
                $html .= "</tr>";
			$html .= "</thead>";
        $html .= "<tbody>";
		return $html;
	}
}

?>
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style_button.css">