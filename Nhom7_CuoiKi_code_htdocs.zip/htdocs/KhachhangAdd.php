<?php
    include 'Connection.php';
    class KhachHangAdd extends Connection
    {
        function execute()
        {
            $MaKH = $_POST['MaKH'];
            $HoLot = $_POST['HoLot'];
            $Ten = $_POST['Ten'];
            $DienThoai = $_POST['DienThoai'];
			$SoDiem = $_POST['SoDiem'];
            $DiaChi = $_POST['DiaChi'];
            if($MaKH !="")
            {
                $sqlCheck = "SELECT * FROM khachhang WHERE KhachhangID = '$MaKH'";
                $resultCheck = $this->query($sqlCheck);
                $check = mysqli_fetch_row($resultCheck);
                if ($check)
                {
                    echo '<script language="javascript">';
                    echo 'alert("Khách hàng bị trùng lặp dữ liệu.")'; 
                    echo '</script>';
                }
                else 
                {
                    $sql_command = "INSERT INTO khachhang(Diachi,Holot,KhachhangID,Sodiem,Sodienthoai,Ten) ";
                     $sql_command .= "VALUES ('$DiaChi', '$HoLot', '$MaKH', '$SoDiem', '$DienThoai', '$Ten')";
                    $result = $this->query($sql_command);
                    echo '<script language="javascript">';
                    echo 'alert("Thêm khách hàng thành công.")';
                    echo '</script>';
                   
                }
            }           
            else
            {
                echo '<script language="javascript">';
                echo 'alert("Vui lòng nhập lại.")';  
                echo '</script>';
            }
            
     }
        
    }
    class KhachHangForm extends KhachHangAdd
    {
        function CreateForm()
        {
            return '<div class="container" >
            
            <form action="index.php?mod=202"  method ="post" >
                <div class = "row">
                    <div class = "col-sm-2"><h5>Mã khách hàng</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="number" name = "MaKH" >
                    </div>
                     <div class = "col-sm-2"><h5>Họ Lót</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "HoLot">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Tên</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "Ten">
                    </div>
                    <div class = "col-sm-2"><h5>Số điện thoại</h5></div>
                    <div class = "col-sm-4">
                        <input type="text" class="form-control input-md" name = "DienThoai" >
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Số điểm</h5></div>
                    <div class = "col-sm-4">
                        <input type="number" class="form-control input-md" name = "SoDiem">
                    </div>
                    <div class = "col-sm-2"><h5>Địa Chỉ</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "DiaChi">
                    </div> 
                </div>
                
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="background-color:royalblue; display:block; margin:0 59vw;" ><b>Xác Nhận</b></button>
            
            </form>
        </div> ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
                echo 'window.location.href = "index.php?mod=200"'; 
                echo '</script>';
                echo "<?php 'Content.php'?>";
            }
        }
    }
?>