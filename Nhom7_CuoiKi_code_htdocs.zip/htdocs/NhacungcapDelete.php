<?php
include 'Connection.php';

class NhaCungCapDeleteById extends Connection
{
	var $id;
	function execute()
	{
		return $this->query("DELETE FROM nhacungcap WHERE CungcapID = ".$this->id);
	}
}
class NhaCungCapDelete extends NhaCungCapDeleteById
{
	function execute()
	{
		parent::execute();
		return "<script>location.href='index.php?mod=300';</script>";
	}
	
}

?>