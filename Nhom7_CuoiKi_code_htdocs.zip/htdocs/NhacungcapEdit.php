<?php
    include 'Connection.php';
    class NhaCungCapEdit extends Connection
    {
        public $id;
        function execute()
        {
            $CungCapID = $_POST['CungCapID'];
            
            $Ten = $_POST['TenNCC'];
            $DienThoai = $_POST['DienThoai'];
			
            $DiaChi = $_POST['DiaChi'];
            if($CungCapID !="")
            {
                $sqlCheck = "SELECT * FROM nhacungcap WHERE CungcapID = '$CungCapID'";
                $resultCheck = $this->query($sqlCheck);
               
                if (mysqli_num_rows($resultCheck) > 1)
                {
                    echo '<script language="javascript">';
                    echo 'alert("Nhà cung cấp bị trùng lặp dữ liệu.")'; 
                    echo '</script>';
                }
                else 
                {
                    $sql_command = "UPDATE nhacungcap SET CungcapID ='$CungCapID', Tennhacungcap ='$Ten', Sodienthoai='$DienThoai', Diachi ='$DiaChi'
                     WHERE CungcapID= ".$this->id;
                      $result = $this->query($sql_command);
                    echo '<script language="javascript">';
                    echo 'alert("Sửa thông tin thành công.")';
                    echo '</script>';
                   
                }
            }           
            else
            {
                echo '<script language="javascript">';
                echo 'alert("Vui lòng nhập lại.")';  
                echo '</script>';
            }
            
            
            return $result;
        }
        function exe3()
        {
             $sqli = "SELECT * from nhacungcap where CungcapID=" .$this->id;
            $query = $this->query($sqli);
            $kqua = array();
            if (mysqli_num_rows($query) > 0){
                $row = mysqli_fetch_assoc($query);
                 //$kqua=$row;
             }
            
           return $row;
        }
    }
    class NhaCungCapForm extends NhaCungCapEdit
    {
        public $id;
       
        function CreateForm()
        {
             $DuLieu = $this-> exe3();
            $what = $this-> id;
            return '
<div class="col">
    <h2>Thay đổi thông tin nhà cung cấp</h2>
    <form class="form-horizontal" action="/index.php?mod=304&ID='.$what.'" method="POST">

        <div class="input-group">
            <span class="input-group-addon ">Mã NCC</span>
            <input type="number" class="form-control" id="CungCapID" name="CungCapID" value = '.$DuLieu['CungcapID'].'>
        </div>
        <br><br>
        
        
        .
        <div class="input-group">
            <span class="input-group-addon">Tên NCC</span>
            <input type="text" class="form-control" id="TenNCC" name="TenNCC" value="' .$DuLieu['Tennhacungcap']. '">
        </div>        
        <br><br>
        
        <div class="input-group">
            <span class="input-group-addon">Số điện thoại</span>
            <input type="number" class="form-control" id="DienThoai" name="DienThoai"  value='.$DuLieu['Sodienthoai'].'>
        </div>
           
        <br><br>
        
        <div class="input-group">
            <span class="input-group-addon">Địa chỉ</span>
            <input type="text" class="form-control" id="DiaChi"  name="DiaChi" value="'.$DuLieu['Diachi'].'">
        </div>        
        
        
         
        <br><br>
        
      <input type="submit" value="Xác nhận" name="submit_form">

    </form>
</div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				//echo 'alert("Sửa thành công")';
                echo 'window.location.href = "index.php?mod=300"'; 
				echo '</script>';
                echo "<?php 'Content.php'?>";
            }
        }
    }
?>
<link rel="stylesheet" type="text/css" href="style_FormNhap.css">
