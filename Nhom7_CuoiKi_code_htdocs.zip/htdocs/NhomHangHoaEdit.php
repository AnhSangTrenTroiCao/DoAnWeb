<?php
    include 'Connection.php';
    class NhomHangHoaEdit extends Connection
    {
        public $id;
        function execute()
        {
            $NHHID = $_POST['NHHID'];
            
            $Ten = $_POST['TenNHH'];
            $GhiChu = $_POST['GhiChu'];
			
            
            if($CungCapID !="")
            {
                $sqlCheck = "SELECT * FROM nhomhanghoa WHERE NhomhanghoaID = '$NHHID'";
                $resultCheck = $this->query($sqlCheck);
               
                if (mysqli_num_rows($resultCheck) > 1)
                {
                    echo '<script language="javascript">';
                    echo 'alert("Nhà cung cấp bị trùng lặp dữ liệu.")'; 
                    echo '</script>';
                }
                else 
                {
                    $sql_command = "UPDATE nhomhanghoa SET NhomhanghoaID ='$NHHID', Tennhomhanghoa ='$Ten', Ghichu ='$GhiChu'
                     WHERE CungcapID= ".$this->id;
                      $result = $this->query($sql_command);
                    echo '<script language="javascript">';
                    echo 'alert("Sửa thông tin thành công.")';
                    echo '</script>';
                   
                }
            }           
            else
            {
                echo '<script language="javascript">';
                echo 'alert("Vui lòng nhập lại.")';  
                echo '</script>';
            }
            
            
            return $result;
        }
        function exe3()
        {
             $sqli = "SELECT * from nhomhanghoa where NhomhanghoaID=" .$this->id;
            $query = $this->query($sqli);
            $kqua = array();
            if (mysqli_num_rows($query) > 0){
                $row = mysqli_fetch_assoc($query);
                 //$kqua=$row;
             }
            
           return $row;
        }
    }
    class NhomHangHoaForm extends NhomHangHoaEdit
    {
        public $id;
       
        function CreateForm()
        {
             $DuLieu = $this-> exe3();
            $what = $this-> id;
            return ' <link rel="stylesheet" type="text/css" href="style_FormNhap.css">
<div class="col">
    <h2>Thay đổi thông tin nhóm hàng hoá</h2>
    <form class="form-horizontal" action="/index.php?mod=404&ID='.$what.'" method="POST">

        <div class="input-group">
            <span class="input-group-addon ">Mã NCC</span>
            <input type="number" class="form-control" id="NHHID" name="NHHID" value = '.$DuLieu['NhomhanghoaID'].'>
        </div>
        <br><br>
        
        
        .
        <div class="input-group">
            <span class="input-group-addon">Tên NCC</span>
            <input type="text" class="form-control" id="TenNHH" name="TenNHH" value="' .$DuLieu['Tennhomhanghoa']. '">
        </div>        
        
        <br><br>
        
        <div class="input-group">
            <span class="input-group-addon">Địa chỉ</span>
            <input type="text" class="form-control" id="GhiChu"  name="GhiChu" value="'.$DuLieu['Ghichu'].'">
        </div>        
        
        
         
        <br><br>
        
      <input type="submit" value="Xác nhận" name="submit_form">

    </form>
</div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				//echo 'alert("Sửa thành công")';
                echo 'window.location.href = "index.php?mod=400"'; 
				echo '</script>';
                echo "<?php 'Content.php'?>";
            }
        }
    }
?>