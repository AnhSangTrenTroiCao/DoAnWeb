<?php
    include 'Connection.php';
    class KhachHangEdit extends Connection
    {
        public $id;
        function execute()
        {
            $MaKH = $_POST['MaKH'];
            $HoLot = $_POST['HoLot'];
            $Ten = $_POST['Ten'];
            $DienThoai = $_POST['DienThoai'];
			$SoDiem = $_POST['SoDiem'];
            $DiaChi = $_POST['DiaChi'];
            if($MaKH !="")
            {
                $sqlCheck = "SELECT * FROM khachhang WHERE KhachhangID = '$MaKH'";
                $resultCheck = $this->query($sqlCheck);
               
                if (mysqli_num_rows($resultCheck) > 1)
                {
                    echo '<script language="javascript">';
                    echo 'alert("Khách hàng bị trùng lặp dữ liệu.")'; 
                    echo '</script>';
                }
                else 
                {
                    $sql_command = "UPDATE khachhang SET KhachhangID ='$MaKH', Holot ='$HoLot', Ten ='$Ten', Sodienthoai='$DienThoai', Sodiem='$SoDiem', Diachi ='$DiaChi'
                     WHERE KhachhangID= ".$this->id;
                      $result = $this->query($sql_command);
                    echo '<script language="javascript">';
                    echo 'alert("Sửa thông tin khách hàng thành công.")';
                    echo '</script>';
                   
                }
            }           
            else
            {
                echo '<script language="javascript">';
                echo 'alert("Vui lòng nhập lại.")';  
                echo '</script>';
            }
            
            
            return $result;
        }
        function exe3()
        {
             $sqli = "SELECT * from khachhang where KhachhangID=" .$this->id;
            $query = $this->query($sqli);
            $kqua = array();
            if (mysqli_num_rows($query) > 0){
                $row = mysqli_fetch_assoc($query);
                 //$kqua=$row;
             }
            
           return $row;
        }
    }
    class KhachHangForm extends KhachHangEdit
    {
        public $id;
       
        function CreateForm()
        {
             $DuLieu = $this-> exe3();
            $what = $this-> id;
            return '
<div class="col">
    <h2>Thay đổi thông tin khách hàng</h2>
    <form class="form-horizontal" action="/index.php?mod=204&ID='.$what.'" method="POST">

        <div class="input-group">
            <span class="input-group-addon ">Mã KH</span>
            <input type="number" class="form-control" id="MaKH" name="MaKH" value = '.$DuLieu['KhachhangID'].'>
        </div>
        <br><br>
        
        <div class="input-group">
            <span class="input-group-addon">Họ lót</span>
            <input type="text" class="form-control" id="HoLot" name="HoLot" value = "'.$DuLieu['Holot'].'">
        </div>        
        <br><br>
        .
        <div class="input-group">
            <span class="input-group-addon">Tên KH</span>
            <input type="text" class="form-control" id="Ten" name="Ten" value="'.$DuLieu['Ten'].'">
        </div>        
        <br><br>
        
        <div class="input-group">
            <span class="input-group-addon">Số điện thoại</span>
            <input type="number" class="form-control" id="DienThoai" name="DienThoai"  value='.$DuLieu['Sodienthoai'].'>
        </div>
        <br><br>
        
        <div class="input-group">
            <span class="input-group-addon">Số điểm</span>
            <input type="number" class="form-control" id="SoDiem"  name="SoDiem"  value='.$DuLieu['Sodiem'].'>
        </div>        
        <br><br>
        
        <div class="input-group">
            <span class="input-group-addon">Địa chỉ</span>
            <input type="text" class="form-control" id="DiaChi"  name="DiaChi" value="'.$DuLieu['Diachi'].'">
        </div>        
        
        
         
        <br><br>
        
      <input type="submit" value="Xác nhận" name="submit_form">

    </form>
</div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				//echo 'alert("Sửa thành công")';
                echo 'window.location.href = "index.php?mod=200"'; 
				echo '</script>';
                echo "<?php 'Content.php'?>";
            }
        }
    }
?>
<link rel="stylesheet" type="text/css" href="style_FormNhap.css">
