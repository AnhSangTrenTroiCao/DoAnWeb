<?php
    include 'Connection.php';
    class NhomHangHoaAdd extends Connection
    {
        function execute()
        {
            $NhomhanghoaID = $_POST['NhomhanghoaID'];
            $Tennhomhanghoa = $_POST['Tennhomhanghoa'];
            $Ghichu = $_POST['Ghichu'];
            if($NhomhanghoaID !="" && $NhomhanghoaID > -1)
            {
                $sqlCheck = "SELECT * FROM nhomhanghoa WHERE NhomhanghoaID = '$NhomhanghoaID'";
                $resultCheck = $this->query($sqlCheck);
                $check = mysqli_fetch_row($resultCheck);
                if ($check)
                {
                    echo '<script language="javascript">';
                    echo 'alert("Nhóm hàng hóa bị trùng lặp dữ liệu.")'; 
                    echo '</script>';
                }
                else 
                {
                    $sql_command = "INSERT INTO nhomhanghoa(NhomhanghoaID,Tennhomhanghoa,Ghichu) ";
                    $sql_command .= "VALUES ('$NhomhanghoaID','$Tennhomhanghoa','$Ghichu')";
                    
                    
                    $result = $this->query($sql_command);
                    echo '<script language="javascript">';
                    echo 'alert("Thêm nhóm hàng hóa thành công.")';
                    echo '</script>';
                    return $result;
                   
                }
            }           
            else
            {
                echo '<script language="javascript">';
                echo 'alert("Vui lòng nhập lại.")';  
                echo '</script>';

            }
            $sql_command = "INSERT INTO nhomhanghoa(NhomhanghoaID,Tennhomhanghoa,Ghichu) ";
            $sql_command .= "VALUES ('$NhomhanghoaID','$Tennhomhanghoa','$Ghichu')";
            $result = $this->query($sql_command);
            return $result;
        }
    }
    class NhomHangHoaForm extends NhomHangHoaAdd
    {
        function CreateForm()
        {
            return '<div class="container" >
            
            <form action="index.php?mod=402"  method ="POST" >
                <div class = "row">
                    <div class = "col-sm-2">Mã Nhóm Hàng Hóa:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "NhomhanghoaID">
                    </div>
                     <div class = "col-sm-2">Tên nhóm hàng hóa:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "Tennhomhanghoa">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Ghi chú:</div>
                    <div class = "col-sm-10">
                        <textarea name = "Ghichu" rows="4" cols="99" style="resize:none"></textarea>
                    </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="display:block; margin:0 61vw;" >OK</button>
            
            </form>
        </div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
                echo 'window.location.href = "index.php?mod=400"'; 
                echo '</script>';
                echo "<?php 'Content.php'?>";
            }
        }
    }
?>