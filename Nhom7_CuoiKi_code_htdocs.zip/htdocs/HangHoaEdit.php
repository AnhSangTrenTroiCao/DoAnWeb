<?php
    include 'Connection.php';
    class HangHoaEdit extends Connection
    {
        public $id;
        function execute()
        {
            $CungCapID = $_POST['CungCapID'];
            $GiaBan = $_POST['GiaBan'];
            $HangHoaID = $_POST['HangHoaID'];
            $MoTa = $_POST['MoTa'];
			$NhomHangHoaID = $_POST['NhomHangHoaID'];
            $SoLuongTonKho = $_POST['SoLuongTonKho'];
            $TenHoangHoa = $_POST['TenHoangHoa'];
            if($CungCapID != "" && $CungCapID > -1 && $HangHoaID != "" && $HangHoaID > -1 && $NhomHangHoaID != "" && $NhomHangHoaID > -1)
            {
                $sqlCheck = "SELECT * FROM hanghoa WHERE HanghoaID = '$HangHoaID";
                $resultCheck = $this->query($sqlCheck);
               
                if (mysqli_num_rows($resultCheck) > 1)
                {
                    echo '<script language="javascript">';
                    echo 'alert("Hàng hoá bị trùng lặp dữ liệu.")'; 
                    echo '</script>';
                }
                else 
                {
                    $sql_command = "UPDATE hanghoa SET HanghoaID ='$HangHoaID', CungcapID ='$CungCapID', Giaban ='$GiaBan', Mota='$MoTa', NhomhanghoaID='$NhomHangHoaID', Soluongtonkho ='$SoLuongTonKho', Tenhanghoa ='$TenHoangHoa'
                     WHERE HanghoaID= ".$this->id;
                      $result = $this->query($sql_command);
                    echo '<script language="javascript">';
                    echo 'alert("Sửa thông tin thành công.")';
                    echo '</script>';
                   
                }
            }           
            else
            {
                echo '<script language="javascript">';
                echo 'alert("Vui lòng nhập lại.")';  
                echo '</script>';
            }
            
            
            return $result;
        }
        function exe3()
        {
             $sqli = "SELECT * from hanghoa where HanghoaID=" .$this->id;
            $query = $this->query($sqli);
            $kqua = array();
            if (mysqli_num_rows($query) > 0){
                $row = mysqli_fetch_assoc($query);
                 //$kqua=$row;
             }
            
           return $row;
        }
    }
    class HangHoaForm extends HangHoaEdit
    {
        public $id;
       
        function CreateForm()
        {
             $DuLieu = $this-> exe3();
            $what = $this-> id;
            return ' 
<div class="container" >
    <h2>Thay đổi thông tin hàng hoá</h2>
    <form action="/index.php?mod=504&ID='.$what.'" method="POST">

        <div class = "row">
            <div class = "col-sm-2"><h5>ID hàng hoá</h5></div>
            <div class = "col-sm-4">
                <input type="number" class="form-control input-md" id="HanghoaID" name="HanghoaID" value = '.$DuLieu['HanghoaID'].'>
            </div>
            <div class = "col-sm-2"><h5>ID nhà cung cấp</h5></div>
            <div class = "col-sm-4">
                <input type="number" class="form-control input-md" id="CungCapID" name="CungCapID" value = "'.$DuLieu['CungcapID'].'">
            </div>        
        </div>
        <br>
        <div class="row">
            <div class = "col-sm-2"><h5>ID nhóm hàng hoá</h5></span></div>
            <div class = "col-sm-4">
                <input type="number" class="form-control input-md" id="NhomHangHoaID" name="NhomHangHoaID" value=' .$DuLieu['NhomhanghoaID']. '>
            </div>
            <div class="col-sm-2"><h5>Giá bán</h5></div>
            <div class = "col-sm-4">
                <input type="text" class="form-control input-md" id="GiaBan" name="GiaBan"  value='.$DuLieu['Giaban'].'>
            </div>
        </div>
        <br>
        <div class="row">
            <div class = "col-sm-2"><h5>Số lượng tồn kho</h5></div>
            <div class = "col-sm-4">
                <input type="text" class="form-control input-md" id="SoLuongTonKho"  name="SoLuongTonKho" value="'.$DuLieu['Soluongtonkho'].'">
            </div>
            <div class="col-sm-2"><h5>Tên hàng hoá</h5></div>
            <div class = "col-sm-4">
                <input type="text" class="form-control input-md" id="TenHoangHoa"  name="TenHoangHoa" value="'.$DuLieu['Tenhanghoa'].'">
            </div> 
        </div>
        <br>
        <div class="row">
            <div class = "col-sm-2"><h5>Mô tả</h5></div>
            <div class = "col-sm-4">
                <input style="width: 239%" type="text" class="form-control input-md" id="MoTa" name="MoTa"  value='.$DuLieu['Mota'].'>
            </div>        
        </div>
        <br>
      <input type="submit" class = "btn btn-info btn-lg " style="background-color:royalblue; display:block; margin:0 59vw;" value="Xác nhận" name="submit_form">

    </form>
</div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				//echo 'alert("Sửa thành công")';
                echo 'window.location.href = "index.php?mod=500"'; 
				echo '</script>';
                echo "<?php 'Content.php'?>";
            }
        }
    }
?>
<link rel="stylesheet" href="style_FormNhap.css">
