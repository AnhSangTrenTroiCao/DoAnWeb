function verify(){
    if(!document.getElementById('ID1').value.trim().length){
        alert("Please enter the remarks");
    }
}