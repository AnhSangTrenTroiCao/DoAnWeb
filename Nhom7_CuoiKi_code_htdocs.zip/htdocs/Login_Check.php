<?php 
session_start();

$conn = mysqli_connect("localhost","root","","quanlybanhang");

$_SESSION['uid'] = $_POST['uid'];
$_SESSION['pwd'] = base64_encode($_POST['pwd']);

if (($_SESSION['uid'])=="" || isset($_SESSION['pwd']) == "" ){
	echo("<script>alert('Đăng nhập không hợp lệ')</script>");
	echo("<script>window.location = 'Login.php';</script>");
}
else{
	$uid = $_SESSION['uid'];
	$sql= "SELECT * FROM taikhoan WHERE Tendangnhap = '$uid';";
	$result = mysqli_query($conn,$sql);

	if (! $row = mysqli_fetch_assoc($result)){
		echo("<script>alert('Tài khoản không tồn tại')</script>");
		echo("<script>window.location = 'Login.php'; </script>");
	}
	else{
		if ($_SESSION['pwd'] == base64_encode($row['Matkhau'])){
			echo("<script>alert('Đăng nhập thành công')</script>");
			echo("<script>window.location = \"index2.php\";</script>");
			
		}
		else{
			echo("<script>alert('Mật không chính xác')</script>");
			echo("<script>window.location = 'Login.php';</script>");
		}
	}
}

?>