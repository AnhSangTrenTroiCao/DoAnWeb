<?php
include 'Connection.php';
class HanghoaSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM hoadon");
	}
    function execute2()
    {
        return $this->query("SELECT sum(Tongtien) FROM hoadon ");
    }
}
class HanghoaList extends HanghoaSelectAll
{
	function execute()
	{
		$data = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($data as $row)
		{
            $money = $this->formatMoney($row['Tongtien'], true);
			$html .= "<tr>";
				$html .= "<td></td>";
				$html .= "<td>{$row['HoadonID']}</td>";
				$html .= "<td>{$row['KhachhangID']}</td>";	
				$html .= "<td>{$row['NhanvienID']}</td>";
				$html .= "<td>{$row['Ngaylap']}</td>";
				$html .= "<td>{$row['Ghichu']}</td>";
				$html .= "<td style='text-align: right;'>$money VNĐ</td>";
				$html .= "<td style='text-align: center;'><a class='btn2' title='Xem chi tiết' href = \"index.php?mod=601&IDHoadon={$row['HoadonID']}\"><i class='fa fa-file-text-o'></a></td>";
			$html .= "</tr>";
		}
        //$html .= "</tbody>";
		$html .= $this->createFooter();

		return $html;
	}
    function formatMoney($number, $fractional=false) {
        if ($fractional) {
            $number = sprintf('%.0f', $number);
        }
        while (true) {
            $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
            if ($replaced != $number) {
                $number = $replaced;
            } else {
                break;
            }
        }
    return $number;
    }
	function createFooter()
	{
        $Dulieu = parent::execute2();
        while ($rows= mysqli_fetch_assoc($Dulieu)){
            $test=$rows['sum(Tongtien)'];
        }
        $money = $this->formatMoney($test,true);
        $html = "";
        $html .='
					
	                        <tr>
                                <th colspan="3" style="text-align: center; border-top:1px solid #999999"> Tổng doanh thu: </th>
                                <th colspan="3" style="border-top:1px solid #999999"></th>
                                <th colspan="1" style="text-align: right;  ;border-top:1px solid #999999"> '.$money.' VNĐ  </th>
                                <th colspan="1" style="border-top:1px solid #999999"></th>
                            </tr>
                    </table>';
        return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            //$html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã hóa đơn</th>";
                    $html .= "<th>Mã khách hàng</th>";
                    $html .= "<th>Mã Nhân viên</th>";
                    $html .= "<th>Ngày lập hóa đơn</th>";
					$html .= "<th>Ghi chú</th>";
					$html .= "<th style='text-align: center;'>Tổng tiền</th>";
        			$html .= "<th style='text-align: center;'>Thao tác</th>";
                $html .= "</tr>";
			//$html .= "</thead>";
        //$html .= "<tbody>";
		return $html;
	}
}
?>
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style_button.css">