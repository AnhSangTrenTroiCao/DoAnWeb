<?php
include_once 'Connection.php';
$connect = mysqli_connect("localhost", "root", "", "quanlybanhang");
$output = '';
if(isset($_POST["export_data"]))
{
    $query = "SELECT * FROM nhanvien ORDER BY NhanvienID DESC";
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0)
    {
        $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                        <th>Mã nhân viên</th>
                        <th>Họ lót</th>  
                        <th>Tên</th>
					    <th>Ngày sinh</th>
					    <th>Ngày vào làm</th>
					    <th>Bộ phận</th>
					    <th>Địa chỉ</th>
					    <th>Chức vụ</th>
                    </tr>
  ';
        while($row = mysqli_fetch_array($result))
        {
            $output .= '
                    <tr>  
                         <td>'.$row["NhanvienID"].'</td>  
                         <td>'.$row["Holot"].'</td>  
                         <td>'.$row["Ten"].'</td>
                         <td>'.$row["Ngaysinh"].'</td>
                         <td>'.$row["Ngayvaolam"].'</td>
                         <td>'.$row["Bophan"].'</td>
                         <td>'.$row["Diachi"].'</td>
                         <td>'.$row["Chucvu"].'</td>
                     </tr>
   ';
        }
        $output .= '</table>';
        header('Content-Type: application/xls');
        header('Content-Disposition: attachment; filename=DSNhanvien_'.date('Y-m-d_H-i-s').'.xls');
        echo $output;
    }
}
?>