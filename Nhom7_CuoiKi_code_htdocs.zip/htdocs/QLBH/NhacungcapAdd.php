<?php
    include 'Connection.php';
    class NhaCungCapAdd extends Connection
    {
        function execute()
        {
            $CungCapID = $_POST['MaNCC'];
            $DiaChi = $_POST['DiaChi'];
            $SDT = $_POST['SDT'];
            $TNCC = $_POST['TNCC'];        
                     
			
          
            $sql_command = "INSERT INTO nhacungcap(CungcapID,Diachi,Sodienthoai,Tennhacungcap) ";
            $sql_command .= "VALUES ('$CungCapID', '$DiaChi', '$SDT','$TNCC')";
            $result = $this->query($sql_command);
            return $result;
        }
    }
    class NhaCungCapForm extends NhaCungCapAdd
    {
        function CreateForm()
        {
            return '<div class="container" >
            
            <form action="index.php?mod=301"  method ="post" >
                <div class = "row">
                    <div class = "col-sm-2">Mã Nhà Cung Cấp:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "MaNCC">
                    </div>
                     <div class = "col-sm-2">Tên Nhà Cung Cấp:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "TNCC">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Địa Chỉ:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "DiaChi">
                    </div>
                    <div class = "col-sm-2">Điện Thoại:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "SDT">
                    </div>
                </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="display:block; margin:0 61vw;" >OK</button>
            
            </form>
        </div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				echo 'alert("Thêm thành công")';
				echo '</script>';
            }
        }
    }
?>