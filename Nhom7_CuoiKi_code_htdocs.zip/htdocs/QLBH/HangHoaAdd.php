<?php
    include 'Connection.php';
    class HangHoaAdd extends Connection
    {
        function execute()
        {
            $CungCapID = $_POST['MaNCC'];
            $GiaBan = $_POST['GiaBan'];
            $HangHoaID = $_POST['HangHoaID'];
            $MoTa = $_POST['MoTa'];
			$NhomHangHoaID = $_POST['NhomHangHoaID'];
            $SoLuongTonKho = $_POST['SoLuongTonKho'];
            $TenHangHoa = $_POST['TenHangHoa'];
            $sql_command = "INSERT INTO hanghoa(CungcapID,Giaban,HanghoaID,Mota,NhomhanghoaID,Soluongtonkho,Tenhanghoa) ";
            $sql_command .= "VALUES ('$CungCapID', '$GiaBan', '$HangHoaID', '$MoTa', '$NhomHangHoaID', '$SoLuongTonKho','$TenHangHoa')";
            $result = $this->query($sql_command);
            return $result;
        }
    }
    class HangHoaForm extends HangHoaAdd
    {
        function CreateForm()
        {
            return '<div class="container" >
            
            <form action="index.php?mod=501"  method ="post" >
                <div class = "row">
                    <div class = "col-sm-2">Mã Nhà Cung Cấp:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "MaNCC">
                    </div>
                     <div class = "col-sm-2">Mã Hàng Hóa:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "HangHoaID">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Nhóm Hàng Hóa:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "NhomHangHoaID">
                    </div>
                    <div class = "col-sm-2">Số Lượng Tồn Kho:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "SoLuongTonKho">
                    </div>
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Tên Hàng Hóa:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "TenHangHoa">
                    </div>
                    <div class = "col-sm-2">Giá Bán:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "GiaBan">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Mô Tả:</div>
                    <div class = "col-sm-10">
                        <textarea name = "MoTa" rows="4" cols="99" style="resize:none"></textarea>
                    </div>
                </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="display:block; margin:0 61vw;" >OK</button>
            
            </form>
        </div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				echo 'alert("Thêm thành công")';
				echo '</script>';
            }
        }
    }
?>