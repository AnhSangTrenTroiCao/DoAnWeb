<?php
	if (!isset($_GET['mod'])){
		return;
	}
	if ($_GET['mod'] == 100){
		echo "href=\"index.php?mod=101\"";
	}
	if ($_GET['mod'] == 200){
		echo "href=\"index.php?mod=202\"";
	}
	if ($_GET['mod'] == 300){
		echo "href=\"index.php?mod=301\"";
	}
	if ($_GET['mod'] == 400){
		echo "href=\"index.php?mod=401\"";
	}
	if ($_GET['mod'] == 500){
		echo "href=\"index.php?mod=501\"";
	}


?>