<?php
    include 'Connection.php';
    class NhanVienAdd extends Connection
    {
        function execute()
        {
            $MaNV = $_POST['MaNV'];
            $HoLot = $_POST['HoLot'];
            $Ten = $_POST['Ten'];
            $NgaySinh = $_POST['NgaySinh'];
			$NgayVaoLam = $_POST['NgayVaoLam'];
			$BoPhan = $_POST['BoPhan'];
            $DiaChi = $_POST['DiaChi'];
            $ChucVu = $_POST['ChucVu'];
            $sql_command = "INSERT INTO nhanvien(Bophan, Chucvu, Diachi, Holot, Ngaysinh, Ngayvaolam, NhanvienID, Ten) ";
            $sql_command .= "VALUES ('$BoPhan', '$ChucVu', '$DiaChi', '$HoLot', '$NgaySinh', '$NgayVaoLam','$MaNV','$Ten')";
            $result = $this->query($sql_command);
            return $result;
        }
    }
    class NhanVienForm extends NhanVienAdd
    {
        function CreateForm()
        {
            return '
            <div class="container" >
            
            <form action="index.php?mod=101"  method ="post" >
                <div class = "row">
                    <div class = "col-sm-2">Mã Nhân Viên:</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "MaNV">
                    </div>
                     <div class = "col-sm-2">Họ Lót:</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "HoLot">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Tên</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "Ten">
                    </div>
                    <div class = "col-sm-2">Ngày Sinh:</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "NgaySinh">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Ngày Vào Làm:</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "NgayVaoLam">
                    </div>
                    <div class = "col-sm-2">Bộ Phận:</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "BoPhan">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Địa Chỉ:</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "DiaChi">
                    </div>
                    <div class = "col-sm-2">Chức Vụ:</div>
                    <div class = "col-sm-4">
                        <input type="text" name = "ChucVu">
                    </div> 
                </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="display:block; margin:0 61vw;" >OK</button>
            
            </form>
        </div>';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				echo 'alert("Thêm thành công")';
				echo '</script>';
            }
        }
    }
?>