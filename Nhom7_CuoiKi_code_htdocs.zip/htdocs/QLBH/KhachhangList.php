﻿<?php
include 'Connection.php';

class KhachhangSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM Khachhang");
	}
}
class KhachhangList extends KhachhangSelectAll
{
	function execute()
	{
		$nv = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($nv as $arr)
		{	
			$html .= "<tr>";
				$html .= "<td></td>";
				$html .= "<td>{$arr['KhachhangID']}</td>";
				$html .= "<td>{$arr['Holot']}</td>";
				$html .= "<td>{$arr['Ten']}</td>";
				$html .= "<td>{$arr['Sodienthoai']}</td>";
				$html .= "<td>{$arr['Sodiem']}</td>";
			$html .= "</tr>";
		}
		$html .= $this->createFooter();
		return $html;
	}
	function createFooter()
	{
		$html = "";
			$html .= "</tbody>";
		$html .= "</table>";
		return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            $html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã Khách hàng</th>";
                    $html .= "<th>Họ lót</th>";
                    $html .= "<th>Tên</th>";
					$html .= "<th>Điện thoại</th>";
					$html .= "<th>Số điểm</th>";
                $html .= "</tr>";
			$html .= "</thead>";
        $html .= "<tbody>";
		return $html;
	}
}

?>