<?php
include 'Connection.php';

class NhacungcapSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM nhacungcap");
	}
}
class NhacungcapList extends NhacungcapSelectAll
{
	function execute()
	{
		$ncc = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($ncc as $arr)
		{	
			$html .= "<tr>";
				$html .= "<td></td>";
				$html .= "<td>{$arr['CungcapID']}</td>";
				$html .= "<td>{$arr['Tennhacungcap']}</td>";
				$html .= "<td>{$arr['Diachi']}</td>";
				$html .= "<td>{$arr['Sodienthoai']}</td>";
			$html .= "</tr>";
		}
		$html .= $this->createFooter();
		return $html;
	}
	function createFooter()
	{
		$html = "";
			$html .= "</tbody>";
		$html .= "</table>";
		return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            $html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã Nhà cung cấp</th>";
                    $html .= "<th>Tên Nhà cung cấp</th>";
                    $html .= "<th>Địa chỉ</th>";
					$html .= "<th>Điện thoại</th>";
                $html .= "</tr>";
			$html .= "</thead>";
        $html .= "<tbody>";
		return $html;
	}
}

?>