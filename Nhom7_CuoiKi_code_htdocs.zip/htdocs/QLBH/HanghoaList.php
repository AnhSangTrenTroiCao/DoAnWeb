<?php
include 'Connection.php';
class HanghoaSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM hanghoa");
	}
}
class HanghoaList extends HanghoaSelectAll
{
	function execute()
	{
		$data = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($data as $row)
		{	
			$html .= "<tr>";
				$html .= "<td></td>";
				$html .= "<td>{$row['CungcapID']}</td>";
				$html .= "<td>{$row['HanghoaID']}</td>";	
				$html .= "<td>{$row['NhomhanghoaID']}</td>";
				$html .= "<td>{$row['Tenhanghoa']}</td>";
				$html .= "<td>{$row['Giaban']}</td>";
				$html .= "<td>{$row['Soluongtonkho']}</td>";
				$html .= "<td>{$row['Mota']}</td>";
			$html .= "</tr>";
		}
		$html .= $this->createFooter();
		return $html;
	}
	function createFooter()
	{
		$html = "";
			$html .= "</tbody>";
		$html .= "</table>";
		return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            $html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã Nhà cung cấp</th>";
                    $html .= "<th>Mã Hàng hóa</th>";
                    $html .= "<th>Mã Nhóm hàng hóa</th>";
                    $html .= "<th>Tên Hàng hóa</th>";
					$html .= "<th>Giá bán</th>";
					$html .= "<th>Số lượng tồn kho</th>";
					$html .= "<th>Mô tả</th>";
                $html .= "</tr>";
			$html .= "</thead>";
        $html .= "<tbody>";
		return $html;
	}
}
?>
