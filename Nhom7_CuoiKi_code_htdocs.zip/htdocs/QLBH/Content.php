﻿
<?php 
	
	if(!isset($_GET['mod']))
		return;
	
	if($_GET['mod'] == '100')
	{	
		include 'NhanvienList.php';
		$item = new NhanvienList();
		echo $item->execute();
		return;
	}
	
	if ($_GET['mod'] == '101'){
		include 'NhanvienAdd.php';
		$item = new NhanvienForm();
		echo $item -> execute();
		return;
	}

	if($_GET['mod'] == '107')
	{	
		include 'NhanvienInput.php';
		$item = new NhanvienInput();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '102')
	{	
		include 'NhanvienInputDelete.php';
		$item = new NhanvienInputDelete();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	
	
	if($_GET['mod'] == '200' )
	{	
		include 'KhachhangList.php';
		$item = new KhachhangList();
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '201')
	{	
		include 'KhachhangInput.php';
		$item = new KhachhangShow();
		$item->id = $_GET['ID'];
		echo $item->execute();
		return;
	}
	if($_GET['mod'] == '202')
	{	
		include 'KhachhangAdd.php';
		$item = new KhachhangForm();
		echo $item->execute();
		return;
	}
	if ($_GET['mod']== '300'){
		include 'NhacungcapList.php';
		$item = new  NhacungcapList();
		echo $item->execute();
		return;
	}
	if ($_GET['mod']== '301'){
		include 'NhaCungCapAdd.php';
		$item = new NhaCungCapForm();
		echo $item->execute();
		return;
	}

	if ($_GET['mod']== '400'){
		include 'NhomhanghoaList.php';
		$item = new  NhomhanghoaList();
		echo $item->execute();
		return;
	}
	if ($_GET['mod']== '401'){
		include 'NhomHangHoaAdd.php';
		$item = new NhomHangHoaForm();
		echo $item->execute();
		return;
	}

	if ($_GET['mod']== '500'){
		include 'HanghoaList.php';
		$item = new HanghoaList();
		echo $item->execute();
		return;
	}
	if ($_GET['mod']== '501'){
		include 'HangHoaAdd.php';
		$item = new HangHoaForm();
		echo $item->execute();
		return;
	}

?> 