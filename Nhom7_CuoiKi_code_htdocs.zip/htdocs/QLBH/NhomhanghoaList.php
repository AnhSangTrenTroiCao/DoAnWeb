<?php
include 'Connection.php';

class NhomhanghoaSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM nhomhanghoa");
	}
}
class NhomhanghoaList extends NhomhanghoaSelectAll
{
	function execute()
	{
		$nhh = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($nhh as $arr)
		{	
			$html .= "<tr>";
				$html .= "<td></td>";	
				$html .= "<td>{$arr['NhomhanghoaID']}</td>";
				$html .= "<td>{$arr['Tennhomhanghoa']}</td>";
				$html .= "<td>{$arr['Ghichu']}</td>";	
			$html .= "</tr>";
		}
		$html .= $this->createFooter();
		return $html;
	}
	function createFooter()
	{
		$html = "";
			$html .= "</tbody>";
		$html .= "</table>";
		return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            $html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã Nhóm hàng hóa</th>";
                    $html .= "<th>Tên Nhóm hàng hóa</th>";
                    $html .= "<th>Ghi chú</th>";
                $html .= "</tr>";
			$html .= "</thead>";
        $html .= "<tbody>";
		return $html;
	}
}

?>