﻿<?php
class Connection
{
	public $con;
	public function __construct()
	{
		$user="root";
		$pass="";
		$database="quanlybanhang";
		$hostname="localhost";
		$this->con = @mysqli_connect($hostname,$user,$pass,$database) or die("Unable to connect");
		@mysqli_query($con,"SET NAMES UTF8");
		
	}
	function query($sql)
	{
		return $this->con->query($sql);
	}
}
?>