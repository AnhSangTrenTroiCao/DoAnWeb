<?php
    include 'Connection.php';
    class KhachHangAdd extends Connection
    {
        function execute()
        {
            $MaKH = $_POST['MaKH'];
            $HoLot = $_POST['HoLot'];
            $Ten = $_POST['Ten'];
            $DienThoai = $_POST['DienThoai'];
			$SoDiem = $_POST['SoDiem'];
            $DiaChi = $_POST['DiaChi'];
            $sql_command = "INSERT INTO khachhang(Diachi,Holot,KhachhangID,Sodiem,Sodienthoai,Ten) ";
            $sql_command .= "VALUES ('$DiaChi', '$HoLot', '$MaKH', '$SoDiem', '$DienThoai', '$Ten')";
            $result = $this->query($sql_command);
            return $result;
        }
    }
    class KhachHangForm extends KhachHangAdd
    {
        function CreateForm()
        {
            return '<div class="container" >
            
            <form action="index.php?mod=202"  method ="post" >
                <div class = "row">
                    <div class = "col-sm-2">Mã Khách Hàng:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "MaKH">
                    </div>
                     <div class = "col-sm-2">Họ Lót:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "HoLot">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Tên:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "Ten">
                    </div>
                    <div class = "col-sm-2">Địa Chỉ:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "DiaChi">
                    </div>
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Số Điện Thoại:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "DienThoai">
                    </div>
                    <div class = "col-sm-2">Số Điểm:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "SoDiem">
                    </div> 
                </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="display:block; margin:0 61vw;" >OK</button>
            
            </form>
        </div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				echo 'alert("Thêm thành công")';
				echo '</script>';
            }
        }
    }
?>