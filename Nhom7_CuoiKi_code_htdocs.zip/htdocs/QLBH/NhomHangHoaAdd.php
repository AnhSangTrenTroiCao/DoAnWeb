<?php
    include 'Connection.php';
    class NhomHangHoaAdd extends Connection
    {
        function execute()
        {
            $NhomhanghoaID = $_POST['NhomhanghoaID'];
            $Tennhomhanghoa = $_POST['Tennhomhanghoa'];
            $Ghichu = $_POST['Ghichu'];
            $sql_command = "INSERT INTO nhomhanghoa(NhomhanghoaID,Tennhomhanghoa,Ghichu) ";
            $sql_command .= "VALUES ('$NhomhanghoaID','$Tennhomhanghoa','$Ghichu')";
            $result = $this->query($sql_command);
            return $result;
        }
    }
    class NhomHangHoaForm extends NhomHangHoaAdd
    {
        function CreateForm()
        {
            return '<div class="container" >
            
            <form action="index.php?mod=401"  method ="POST" >
                <div class = "row">
                    <div class = "col-sm-2">Mã Nhóm Hàng Hóa:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "NhomhanghoaID">
                    </div>
                     <div class = "col-sm-2">Tên nhóm hàng hóa:</div>
                    <div class = "col-sm-4">
                        <input type="text"  name = "Tennhomhanghoa">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2">Ghi chú:</div>
                    <div class = "col-sm-10">
                        <textarea name = "Ghichu" rows="4" cols="99" style="resize:none"></textarea>
                    </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="display:block; margin:0 61vw;" >OK</button>
            
            </form>
        </div>
            ';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				echo 'alert("Thêm thành công")';
				echo '</script>';
            }
        }
    }
?>