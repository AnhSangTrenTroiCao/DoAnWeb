<?php
include 'Connection.php';

class HangHoaDeleteById extends Connection
{
	var $id;
	function execute()
	{
		return $this->query("DELETE FROM hanghoa WHERE HanhoaID = ".$this->id);
	}
}
class HangHoaDelete extends HangHoaDeleteById
{
	function execute()
	{
		parent::execute();
		return "<script>location.href='index.php?mod=500';</script>";
	}
	
}

?>