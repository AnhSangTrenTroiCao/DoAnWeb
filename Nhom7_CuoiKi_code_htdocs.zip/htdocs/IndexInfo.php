﻿<?php
class IndexInfo
{
	//var id;
	function getTitle()
	{
		if(!isset($_GET['mod']))
		{
			return "Trang chủ";
		}
		$arr = [
			100=>"Danh sách Nhân viên",
			101=>"Đăng ký Nhân viên",
			102=>"Xóa Nhân viên",
			104=>"Thông tin nhân viên",
			200=>"Danh sách Khách hàng",
			203=>"Sửa khách hàng",
			300=>"Danh sách Nhà cung cấp",
			400=>"Danh sách nhóm hàng hóa",
			500=>"Danh sách hàng hóa",
			600=>"Bán hàng"
		];
		if(in_array($_GET['mod'], $arr))
		{
			return $arr[$_GET['mod']];
		}
		return $arr[$_GET['mod']- $_GET['mod']%100];
	}
	function getClass($menu_id)
	{
		if($_GET['mod'] - $_GET['mod']%100 == $menu_id)
		{
			return "active";
		}
		return "";
	}
} 
$indexInfo = new IndexInfo();
?> 