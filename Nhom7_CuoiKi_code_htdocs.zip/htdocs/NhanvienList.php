﻿<?php
include 'Connection.php';

class NhanvienSelectAll extends Connection
{
	function execute()
	{
		return $this->query("SELECT * FROM nhanvien ORDER BY NhanvienID DESC LIMIT 10");
	}
}
class NhanvienList extends NhanvienSelectAll
{
	function execute()
	{
		$data = parent::execute();
		$html = "";	
		$html .= $this->createHeader();
		foreach($data as $row)
		{	
			$html .= "<tr>";
				$html .= "<td></td>";
				$html .= "<td>{$row['NhanvienID']}</td>";
				$html .= "<td><a href = \"index.php?mod=101&ID={$row['NhanvienID']}\">{$row['Holot']}</a></td>";
				$html .= "<td>{$row['Ten']}</td>";
				$html .= "<td>{$row['Ngaysinh']}</td>";
				$html .= "<td>{$row['Ngayvaolam']}</td>";
				$html .= "<td>{$row['Bophan']}</td>";
				$html .= "<td>{$row['Diachi']}</td>";
				$html .= "<td>{$row['Chucvu']}</td>";
				$html .= "<td><a class='btn2' title='Xoá' href = \"index.php?mod=102&ID={$row['NhanvienID']}\"><i class='fa fa-trash-o'></i></a>";
				$html .= "<a>  </a><a class='btn2' title='Sửa' href = \"index.php?mod=104&ID={$row['NhanvienID']}\"><i class='fa fa-edit'></i></a></td>";
			$html .= "</tr>";
		}
		$html .= $this->createFooter();
		return $html;
	}
	function createFooter()
	{
		$html = "";
			$html .= "</tbody>";
		$html .= "</table>";
		return $html;
	}
	function createHeader()
	{
		$html = "";
		$html .= "<table class=\"table table-advance\" id=\"table1\">";
            $html .= "<thead>";
                $html .= "<tr>";
                    $html .= "<th style=\"width:18px\"></th>";
                    $html .= "<th>Mã nhân viên</th>";
                    $html .= "<th>Họ lót</th>";
                    $html .= "<th>Tên</th>";
					$html .= "<th>Ngày sinh</th>";
					$html .= "<th>Ngày vào làm</th>";
					$html .= "<th>Bộ phận</th>";
					$html .= "<th>Địa chỉ</th>";
					$html .= "<th>Chức vụ</th>";
        			$html .= "<th>Thao tác</th>";
                $html .= "</tr>";
			$html .= "</thead>";
        $html .= "<tbody>";
		return $html;
	}
}
?>
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style_button.css">
