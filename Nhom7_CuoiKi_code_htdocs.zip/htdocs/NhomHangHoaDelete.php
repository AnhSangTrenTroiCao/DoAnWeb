<?php
include 'Connection.php';

class NhomHangHoaDeleteById extends Connection
{
	var $id;
	function execute()
	{
		return $this->query("DELETE FROM nhomhanghoa WHERE NhomhanghoaID = ".$this->id);
	}
}
class NhomHangHoaDelete extends NhomHangHoaDeleteById
{
	function execute()
	{
		parent::execute();
		return "<script>location.href='index.php?mod=400';</script>";
	}
	
}

?>