<?php
class BreadcrumbInfo
{
	//var id;
	function getTitle()
	{
		if(!isset($_GET['mod']))
		{
			return "";
		}
		$arr = [
			100=>"<span class=\"divider\"><i class=\"fa fa-angle-right\"></i></span>Nhân viên",
			200=>"<span class=\"divider\"><i class=\"fa fa-angle-right\"></i></span>Khách hàng",
			300=>"<span class=\"divider\"><i class=\"fa fa-angle-right\"></i></span>Nhà cung cấp",
			400=>"<span class=\"divider\"><i class=\"fa fa-angle-right\"></i></span>Nhóm hàng hóa",
			500=>"<span class=\"divider\"><i class=\"fa fa-angle-right\"></i></span>Hàng hóa",
			600=>"<span class=\"divider\"><i class=\"fa fa-angle-right\"></i></span>Bán hàng"
		];
		if(in_array($_GET['mod'], $arr))
		{
			return $arr[$_GET['mod']];
		}
		return $arr[$_GET['mod']- $_GET['mod']%100];
	}
	function getClass($menu_id)
	{
		if($_GET['mod'] - $_GET['mod']%100 == $menu_id)
		{
			return "active";
		}
		return "";
	}
} 
$breadcrumbinfo = new BreadcrumbInfo();
?> 