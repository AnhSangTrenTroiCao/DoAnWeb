<?php
include 'Connection.php';
class Chitiet extends Connection{
    var $HoadonID;
    function execute()
    {
        $HoadonID= $this->HoadonID;
        //if ( $HoadonID !="" && $HoadonID > -1){
        $sqlCheck = "SELECT * FROM cthoadon WHERE HoadonID = '$HoadonID'";
        $resultCheck = $this->query($sqlCheck);
        $result = mysqli_fetch_assoc($resultCheck);
        $html = "";
        $html .= $this->createHeader();
        foreach ($resultCheck as $arr) {
            $html .= "<tr>
                <td></td>
                <td>{$arr['Ghichu']}</td>
                <td>{$arr['HoahoaID']}</td>
                <td>{$arr['HoadonID']}</td>
                <td>{$arr['Ngaylap']}</td>
                <td>{$arr['Soluong']}</td>
                <br>
              
        </tr>";
        }
        $html .= $this->createFooter();
        return $html;
    }
    function createFooter()
    {
        $html = "";
        $html .= "</tbody>";
        $html .= "</table>";
        $html .= "<br>";
        $html .= "<a class='btn2' title='Quay lại' href=\"index.php?mod=600\" style='float:right;'><b>Quay lại</b></a>";
        return $html;
    }
    function createHeader()
    {
        $html = "";
        $html .= "<table class=\"table table-advance\" id=\"table1\">";
        $html .= "<thead>";
        $html .= "<tr>";
        $html .= "<th style=\"width:18px\"></th>";
        $html .= "<th>Ghi chú</th>";
        $html .= "<th>Hàng hoá ID</th>";
        $html .= "<th>Hoá đơn ID</th>";
        $html .= "<th>Ngày lập</th>";
        $html .= "<th>Số lượng</th>";


        $html .= "</tr>";
        $html .= "</thead>";
        $html .= "<tbody>";
        return $html;
    }
}






	/*include 'Connection.php';
	class Chitiet extends Connection{
		var $HoadonID;
		function execute()
		{
			$HoadonID= $this->HoadonID;
			if ( $HoadonID !="" && $HoadonID > -1){
				$sqlCheck = "SELECT * FROM cthoadon WHERE HoadonID = '$HoadonID'";
                $resultCheck = $this->query($sqlCheck);
                $result = mysqli_fetch_assoc($resultCheck);
                echo'
                <div class="container" >
                <form >
                <div class = "row">
                    <div class = "col-sm-2"><h5>Mã hóa đơn</h5></div>
                    <div class = "col-sm-4">
                        <input type="text" name = "MaHD" value = "'.$result["HoadonID"].'">
                    </div>
                     <div class = "col-sm-2"><h5>Mã hàng hóa</h5></div>
                    <div class = "col-sm-4">
                        <input type="text" name = "MaHH" value = "'.$result['HoahoaID'].'">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Ghi chú</h5></div>
                    <div class = "col-sm-4">
                        <input type="text" name = "Ghichu" value = "'.$result['Ghichu'].'" >
                    </div>
                    <div class = "col-sm-2"><h5>Ngày lập</h5></div>
                    <div class = "col-sm-4">
                        <input type="text" name = "Ngaylap" value = "'.$result['Ngaylap'].'" >
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Số lượng</h5></div>
                    <div class = "col-sm-4">
                        <input type="text" name = "Soluong" value = "'.$result['Soluong'].'" >
                    </div>
                </div>
                <br>
                
                <br>
                <button class = "btn btn-info btn-lg " style="background-color:lightblue; display:block; margin:0 59vw;"><b><a href="index.php?mod=600">Quay lại</a></b></button>
				</form>
        		</div>';

			}
			else{
				echo "<script> alert('Không tìm thấy hóa đơn')</script>";
			}
		}
	}*/?>
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style_button2.css">
