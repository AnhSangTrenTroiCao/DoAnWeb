<?php
    include 'Connection.php';
    class NhanVienAdd extends Connection
    {
        function execute()
        {
            $MaNV = $_POST['MaNV'];
            $HoLot = $_POST['HoLot'];
            $Ten = $_POST['Ten'];
            $NgaySinh = $_POST['NgaySinh'];
			$NgayVaoLam = $_POST['NgayVaoLam'];
			$BoPhan = $_POST['BoPhan'];
            $DiaChi = $_POST['DiaChi'];
            $ChucVu = $_POST['ChucVu'];
            if($MaNV !="")
            {
                $sqlCheck = "SELECT * FROM nhanvien WHERE NhanvienID = '$MaNV'";
                $resultCheck = $this->query($sqlCheck);
                $check = mysqli_fetch_row($resultCheck);
                if ($check)
                {
                    echo "<h3 style='color:red;'><b><i>Đã tồn tại nhân viên</h3></b></i>";
                }
                else 
                {
                    $sql_command = "INSERT INTO nhanvien(Bophan, Chucvu, Diachi, Holot, Ngaysinh, Ngayvaolam, NhanvienID, Ten) ";
                    $sql_command .= "VALUES ('$BoPhan', '$ChucVu', '$DiaChi', '$HoLot', '$NgaySinh', '$NgayVaoLam','$MaNV','$Ten')";
                    echo "<h3 style='color:blue;'><b><i>Nhập thành công</h3></b></i>";
                    $result = $this->query($sql_command);
                    return $result; 
                }
            }           
            else
            {
                echo "<h3 style='color:red;'><b><i>Vui lòng nhập lại</h3></b></i>";
            }
        }
    }
    class NhanVienForm extends NhanVienAdd
    {
        function CreateForm()
        {
            return '
            <div class="container" >
            
            <form action="index.php?mod=101"  method ="post" >
                <div class = "row">
                    <div class = "col-sm-2"><h5>Mã Nhân Viên</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="number" name = "MaNV" max = 10000000>
                    </div>
                     <div class = "col-sm-2"><h5>Họ Lót</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "HoLot">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Tên</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "Ten">
                    </div>
                    <div class = "col-sm-2"><h5>Ngày Sinh</h5></div>
                    <div class = "col-sm-4">
                        <input type="date" class="form-control input-md" name = "NgaySinh" >
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Ngày Vào Làm</h5></div>
                    <div class = "col-sm-4">
                        <input type="date" class="form-control input-md" name = "NgayVaoLam">
                    </div>
                    <div class = "col-sm-2"><h5>Bộ Phận</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "BoPhan">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Địa Chỉ</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "DiaChi">
                    </div>
                    <div class = "col-sm-2"><h5>Chức Vụ</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "ChucVu">
                    </div> 
                </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="background-color:royalblue; display:block; margin:0 59vw;" ><b>Xác Nhận</b></button>
            
            </form>
        </div>';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
                echo 'location="index.php?mod=100"';
				echo '</script>';

            }
        }
    }
?>
