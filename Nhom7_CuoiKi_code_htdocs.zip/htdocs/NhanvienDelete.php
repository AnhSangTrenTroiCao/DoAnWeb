<?php
	global $conn;

function connect_db()
{
  
    global $conn;
    
   
    if (!$conn){
        $conn = mysqli_connect('localhost', 'root', '', 'quanlybanhang') or die ('Can\'t not connect to database');
      
        mysqli_set_charset($conn, 'utf8');
    }
}
function disconnect_db()
{
    
    global $conn;
    
    
    if ($conn){
        mysqli_close($conn);
    }
}
function delete_nhanvien($ID)
{
  
    global $conn;
    
  
    connect_db();
    
    
    $sql = "
            DELETE FROM nhanvien
            WHERE NhanvienID = $ID
    ";
    
  
    $query = mysqli_query($conn, $sql);
    
    return $query;
}

?>