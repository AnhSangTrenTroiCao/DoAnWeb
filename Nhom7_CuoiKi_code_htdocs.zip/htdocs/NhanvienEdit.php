<?php
    include 'Connection.php';


    class NhanVienAdd extends Connection
    {
        public $id;
        function execute()
        {
            $MaNV = $_POST['MaNV'];
            $HoLot = $_POST['HoLot'];
            $Ten = $_POST['Ten'];
            $NgaySinh = $_POST['NgaySinh'];
			$NgayVaoLam = $_POST['NgayVaoLam'];
			$BoPhan = $_POST['BoPhan'];
            $DiaChi = $_POST['DiaChi'];
            $ChucVu = $_POST['ChucVu'];
            $sql_command = "UPDATE nhanvien SET Bophan ='$BoPhan', Chucvu ='$ChucVu', Diachi ='$DiaChi', Holot='$HoLot', Ngaysinh='$NgaySinh', Ngayvaolam ='$NgayVaoLam', Ten ='$Ten' 
WHERE NhanvienID= ".$this->id;
            
            $result = $this->query($sql_command);
            return $result;
        }
        function exe2()
        {
            $sql = "select * from nhanvien where NhanvienID=".$this->id;
            $query = $this->query($sql);
            $kqua = array();
            if (mysqli_num_rows($query) > 0){
                $row = mysqli_fetch_assoc($query);
                $kqua=$row;
             }
            
           return $kqua;
        }
    }

    class NhanVienForm extends NhanVienAdd
    {
        public $id;
              function CreateForm()
        {
            $DuLieu = $this-> exe2();
            $what = $this-> id;
            return '
       <div class="container" >
            
            <form action="index.php?mod=104&ID='.$what.'"  method ="post" >
                <div class = "row">
                    <div class = "col-sm-2"><h5>Mã Nhân Viên</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="number" name = "MaNV" max = 1000000000 value='.$DuLieu['NhanvienID'].'>
                    </div>
                     <div class = "col-sm-2"><h5>Họ Lót</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "HoLot" value="'.$DuLieu['Holot'].'">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Tên</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "Ten" value="'.$DuLieu['Ten'].'">
                    </div>
                    <div class = "col-sm-2"><h5>Ngày Sinh</h5></div>
                    <div class = "col-sm-4">
                        <input type="date" class="form-control input-md" name = "NgaySinh" value="'.$DuLieu['Ngaysinh'].'">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Ngày Vào Làm</h5></div>
                    <div class = "col-sm-4">
                        <input type="date" class="form-control input-md" name = "NgayVaoLam" value="'.$DuLieu['Ngayvaolam'].'">
                    </div>
                    <div class = "col-sm-2"><h5>Bộ Phận</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "BoPhan" value="'.$DuLieu['Bophan'].'">
                    </div> 
                </div>
                <br>
                <div class = "row">
                    <div class = "col-sm-2"><h5>Địa Chỉ</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "DiaChi" value="'.$DuLieu['Diachi'].'">
                    </div>
                    <div class = "col-sm-2"><h5>Chức Vụ</h5></div>
                    <div class = "col-sm-4">
                        <input class="form-control input-md" type="text" name = "ChucVu" value="'.$DuLieu['Chucvu'].'">
                    </div> 
                </div>
                <br>
                <button name="submit_form" type="submit" class = "btn btn-info btn-lg " style="background-color:royalblue; display:block; margin:0 59vw;" ><b>Xác Nhận</b></button>
            
            </form>
        </div>';
        }
        function execute()
        {
            $html = $this->CreateForm();
            echo $html;
            if(isset($_POST['submit_form'])){
                $data = parent::execute();
				echo '<script language="javascript">';
				echo 'alert("Sửa thành công")';
				echo '</script>';
            }
        }
    }
?>
